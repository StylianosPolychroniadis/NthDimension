# opengl-skydome
A fragment-shader skydome implementation, in OpenGL and GLSL.

More details (in french) on [my blog](http://blog.simonrodriguez.fr/articles/28-06-2015_un_ciel_dans_le_shader.html) 
